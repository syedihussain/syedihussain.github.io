import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;


public class ClockAnimation extends Application {
    @Override // Override the start method in the Application class

    public void start(Stage primaryStage) throws Exception
    {
        ClockPane clock = new ClockPane();
        Scene scene = new Scene(clock, 400, 400);

        EventHandler<ActionEvent> eventHandler = e -> {
            try {
                clock.setCurrentTime();
            }catch(Exception e1 ) {

            }
        };


        Button submitButton = new Button("Submit");
        TextField inputBoxText = new TextField();
        inputBoxText.setPrefColumnCount(20);
        submitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {

                    String country = inputBoxText.getText();
                    country = country.replaceAll(" ","-");
                    clock.changeCountry(country);
                    Timeline animation = new Timeline(new KeyFrame(Duration.millis(1000), eventHandler));

                    animation.setCycleCount(Timeline.INDEFINITE);
                    animation.setCycleCount(Timeline.INDEFINITE);
                    animation.play();
                    primaryStage.setScene(scene);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.add(inputBoxText,4,4);
        pane.add(submitButton,1,4);
        Scene startScene = new Scene(pane,400,400);
        primaryStage.setScene(startScene);


        primaryStage.setTitle("ClockAnimation");

        primaryStage.show();
    }
}